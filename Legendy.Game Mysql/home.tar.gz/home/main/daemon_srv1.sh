#!/bin/sh
#### @martysama0134 start scripts ####
while true; do
	./start.py &
	sleep 10
done

